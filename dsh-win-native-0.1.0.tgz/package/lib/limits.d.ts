/**
 * Plugin configuration and the per-call budgets derived from it.
 * @module dsh-win-native/limits
 */
import z from '@deepseek-ai/schemastery';
/** Effective budgets for one plugin instance. */
export interface Limits {
    /** Hard ceiling on a structured (text or base64) input payload, in UTF-8 bytes. */
    maxInputBytes: number;
    /** Soft ceiling on a rendered result, in UTF-8 bytes. */
    maxOutputBytes: number;
    /** Hard ceiling on decoded raw bytes for the encoding tools, in bytes. */
    maxRawBytes: number;
    /** Ceiling on listening/established entries reported by a socket parse. */
    maxEntries: number;
    /** Ceiling on characters of decoded text echoed by a conversion. */
    maxTextChars: number;
    /** Default ceiling on files walked by `dir_usage`, when the call omits one. */
    maxFiles: number;
    /** Default ceiling on total accounted bytes for `dir_usage`. */
    maxBytes: number;
    /** Default ceiling on bytes hashed by `file_duplicates`. */
    maxBytesHashed: number;
    /** Ceiling on unreadable-path records reported by a filesystem tool. */
    maxErrors: number;
}
/** Default budgets: large enough for one real directory, small enough to stay bounded. */
export declare const DEFAULT_LIMITS: Limits;
/** User-facing configuration. */
export interface Config {
    /** Hard ceiling on a structured input payload, in UTF-8 bytes. */
    maxInputBytes?: number;
    /** Soft ceiling on a rendered result, in UTF-8 bytes. */
    maxOutputBytes?: number;
    /** Hard ceiling on decoded raw bytes for the encoding tools. */
    maxRawBytes?: number;
    /** Ceiling on socket entries reported by `netstat_parse`. */
    maxEntries?: number;
    /** Ceiling on characters of decoded text echoed by `encoding_convert`. */
    maxTextChars?: number;
    /** Default file budget for `dir_usage` and `file_duplicates`. */
    maxFiles?: number;
    /** Default byte-accounting budget for `dir_usage`. */
    maxBytes?: number;
    /** Default hashing budget for `file_duplicates`. */
    maxBytesHashed?: number;
    /** Ceiling on unreadable-path records. */
    maxErrors?: number;
    /** Tool-name prefix, e.g. `win` yields `win__path_inspect`. Empty by default. */
    toolPrefix?: string;
    /** Register only these tool names (empty or omitted registers every tool). */
    only?: string[];
}
/** Schemastery schema for {@link Config}. */
export declare const Config: z<Config>;
/**
 * Merge user configuration over the defaults.
 * @param config - user configuration, possibly empty.
 */
export declare function resolveLimits(config?: Config): Limits;
