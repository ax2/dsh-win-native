/**
 * DSH tool definitions. Each tool is a thin, declarative binding: a parameter
 * schema for the model, a bounded body, and the shared receipt renderer.
 *
 * Two families live here. `encoding_detect`, `encoding_convert`, `path_inspect`
 * and `netstat_parse` are pure functions over text. `dir_usage` and
 * `file_duplicates` read the local filesystem and nothing else: they never
 * write, never follow reparse points, never resolve relative paths against the
 * process working directory, and report every budget and every unreadable path.
 * @module dsh-win-native/tools
 */
import { type ParameterSchemaSpec, type ToolDefinition, type ValueSchemaSpec } from '@deepseek-ai/dsh-tools';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import { type Envelope } from './core/receipt.ts';
import type { Limits } from './limits.ts';
/** Tool groups, used by the `only` config filter and documentation. */
export type ToolGroup = 'encoding' | 'path' | 'network' | 'filesystem';
/** One tool body: model-facing schema plus a bounded implementation. */
export interface ToolBody {
    /** Tool name as the model sees it. */
    name: string;
    /** Model-facing description; states the bounds and what the tool refuses. */
    description: string;
    /** Parameter schema. */
    parameters: ParameterSchemaSpec;
    /** Canonical result schema for the `result` field. */
    result: ValueSchemaSpec;
    /** Group used by the `only` filter. */
    group: ToolGroup;
    /** Implementation receiving validated arguments and the effective budgets. */
    run(args: Record<string, unknown>, limits: Limits, exec: {
        signal: AbortSignal;
    }): Envelope<JsonValue> | Promise<Envelope<JsonValue>>;
}
/** Options shared by every tool built for one plugin instance. */
export interface ToolFactoryOptions {
    /** Effective budgets. */
    limits: Limits;
    /** Optional tool-name prefix, joined with `__`. */
    prefix?: string;
    /** Register only these base tool names; empty registers every tool. */
    only?: readonly string[];
}
/**
 * Build a registry-ready definition with the shared receipt renderer.
 *
 * The registry validates the canonical value against the declared per-tool
 * `result` schema; only the author-facing generic is erased, because
 * `InferValue` collapses over a broad `ValueSchemaSpec` union. The pairing is
 * asserted by the tool tests instead.
 * @param body - tool body.
 * @param opts - budgets, name prefix, and allowlist for this plugin instance.
 */
export declare function defineReceiptTool(body: ToolBody, opts: ToolFactoryOptions): ToolDefinition | undefined;
/** Compile a parameter schema to JSON Schema, proving the DSL node is valid. */
export declare function compileParameters(spec: ParameterSchemaSpec): import("@deepseek-ai/dsh-tools").ParameterJsonSchema;
/**
 * Every tool this package registers, in registration order.
 * @param opts - budgets, name prefix, and optional allowlist.
 */
export declare function createTools(opts: ToolFactoryOptions): ToolDefinition[];
