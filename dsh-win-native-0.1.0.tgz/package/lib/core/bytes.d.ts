/**
 * UTF-8 byte accounting, hard input bounds, base64 transport helpers, and
 * lossless text clipping.
 *
 * Framework-agnostic on purpose: every rule here is testable without a DSH host
 * and reusable by any surface that embeds these tools.
 * @module dsh-win-native/core/bytes
 */
/** Raised when a payload exceeds the configured input budget. */
export declare class BoundedInputError extends Error {
    /** Stable, machine-readable failure code. */
    readonly code = "INPUT_TOO_LARGE";
    /** Measured UTF-8 size of the rejected payload. */
    readonly actualBytes: number;
    /** Configured ceiling in UTF-8 bytes. */
    readonly limitBytes: number;
    /**
     * @param actualBytes - measured UTF-8 size of the rejected payload.
     * @param limitBytes - configured ceiling in UTF-8 bytes.
     * @param what - short label for the payload, used in the message.
     */
    constructor(actualBytes: number, limitBytes: number, what?: string);
}
/** Raised when a requested operation or option value is not supported. */
export declare class UnsupportedOptionError extends Error {
    /** Stable, machine-readable failure code. */
    readonly code = "UNSUPPORTED_OPTION";
    /** The option name that carried the bad value. */
    readonly option: string;
    /**
     * @param option - the option name that carried the bad value.
     * @param value - the unsupported value.
     * @param allowed - permitted values.
     */
    constructor(option: string, value: unknown, allowed: readonly string[]);
}
/** Raised when a caller passes a relative path to a filesystem tool. */
export declare class AbsolutePathRequiredError extends Error {
    /** Stable, machine-readable failure code. */
    readonly code = "ABSOLUTE_PATH_REQUIRED";
    /**
     * @param path - the rejected path.
     */
    constructor(path: string);
}
/** UTF-8 byte length of a string. */
export declare function utf8Bytes(text: string): number;
/**
 * Enforce that a caller-supplied path is absolute in Windows terms.
 *
 * `path.win32.isAbsolute` is used rather than the host's `isAbsolute` so the
 * refusal is identical on a Windows host, a Linux CI runner and a container:
 * `C:\x` and `\\server\share` are absolute everywhere, `C:x` and `x\y` are not.
 * @param value - candidate path.
 * @returns the path when it is absolute.
 * @throws {AbsolutePathRequiredError} when it is not.
 */
export declare function assertAbsolutePath(value: string): string;
/**
 * Whether a path is absolute under Windows rules.
 * @param value - candidate path.
 */
export declare function isAbsoluteWindows(value: string): boolean;
/** UTF-8 byte length of any canonical JSON value. */
export declare function jsonBytes(value: unknown): number;
/**
 * Measure a payload and refuse it when it exceeds the budget.
 * @param text - payload to measure.
 * @param limitBytes - configured ceiling.
 * @param what - label used in the error message.
 * @returns the measured byte length when the payload fits.
 */
export declare function assertWithinInput(text: string, limitBytes: number, what?: string): number;
/**
 * Clip a string to a byte budget without splitting a code point.
 * @param text - source string.
 * @param maxBytes - byte ceiling.
 * @returns the clipped text, its byte length, and whether clipping happened.
 */
export declare function clipToBytes(text: string, maxBytes: number): {
    text: string;
    bytes: number;
    truncated: boolean;
};
/**
 * Clip an array to a maximum number of entries.
 * @param items - source array.
 * @param maxItems - entry ceiling.
 * @returns the clipped array and whether clipping happened.
 */
export declare function clipItems<T>(items: readonly T[], maxItems: number): {
    items: T[];
    truncated: boolean;
};
/** Stable failure code for a base64 payload that is not decodable. */
export declare class InvalidBase64Error extends Error {
    /** Stable, machine-readable failure code. */
    readonly code = "INVALID_BASE64";
    /**
     * @param detail - what exactly was rejected.
     */
    constructor(detail: string);
}
/**
 * Decode a base64 payload, accepting standard and URL-safe alphabets with or
 * without padding and ignoring embedded whitespace/newlines.
 *
 * Models routinely emit line-wrapped or URL-safe base64; rejecting those would
 * turn a formatting quirk into a failed task, so the alphabet is normalized
 * before the strict length/padding check runs.
 * @param text - candidate base64 text.
 * @returns decoded bytes.
 * @throws {InvalidBase64Error} when the payload is not decodable base64.
 */
export declare function decodeBase64(text: string): Buffer;
/**
 * Encode bytes as canonical padded standard base64.
 * @param bytes - raw bytes.
 */
export declare function encodeBase64(bytes: Buffer): string;
/**
 * Render a short, deterministic lowercase hex preview of a byte buffer.
 * @param bytes - raw bytes.
 * @param maxBytes - number of leading bytes to include.
 * @returns hex preview plus whether bytes were withheld.
 */
export declare function hexPreview(bytes: Buffer, maxBytes: number): {
    hex: string;
    previewBytes: number;
    truncated: boolean;
};
