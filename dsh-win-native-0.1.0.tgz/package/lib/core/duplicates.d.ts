/** Budgets for one duplicate scan. */
export interface DuplicateOptions {
    /** Maximum files collected by the walk. */
    maxFiles: number;
    /** Maximum directory depth below the root. */
    maxDepth: number;
    /** Maximum total bytes fed through the hash function. */
    maxBytesHashed: number;
    /** Cancellation signal, checked between files. */
    signal: AbortSignal;
    /** How many unreadable paths to report. */
    maxErrors: number;
}
/** One candidate file, before hashing. */
export interface CandidateFile {
    /** Absolute path. */
    path: string;
    /** Size in bytes, used for the initial grouping. */
    size: number;
}
/** One group of byte-identical files. */
export interface DuplicateGroup {
    /** SHA-256 of the shared content, hex encoded. */
    hash: string;
    /** Size of every file in the group, in bytes. */
    size: number;
    /** How many copies exist. */
    count: number;
    /** Bytes reclaimable by keeping one copy. */
    reclaimable: number;
    /** Every path in the group, sorted. */
    paths: string[];
}
/** A path that could not be read during the scan. */
export interface UnreadableFile {
    /** The path. */
    path: string;
    /** Node error code, for example `EACCES`, `EBUSY`, `EPERM`. */
    code: string;
    /** Node error message. */
    message: string;
    /** Stage that failed: `stat`, `read`, or `list`. */
    stage: 'stat' | 'read' | 'list';
}
/** Result of a duplicate scan. */
export interface DuplicateReport {
    /** Directory that was scanned. */
    root: string;
    /** Duplicate groups, largest reclaimable first. */
    groups: DuplicateGroup[];
    /** Total bytes reclaimable across every group. */
    reclaimable_bytes: number;
    /** Number of files that had at least one same-size sibling. */
    candidates_hashed: number;
    /** Number of files read and hashed. */
    files_hashed: number;
    /** Bytes fed through SHA-256. */
    bytes_hashed: number;
    /** Files collected before stage one. */
    files_seen: number;
    /** Paths that could not be read, with the error code. */
    unreadable: UnreadableFile[];
    /** Whether a budget stopped the scan early. */
    truncated: boolean;
    /** Budget and coverage notes. */
    notes: string[];
}
/**
 * Stream one file through SHA-256 without buffering it.
 *
 * Streaming is what keeps the tool inside a sane memory footprint on a tree with
 * multi-gigabyte files; the read stream is destroyed as soon as it emits an
 * error so a broken file cannot leak a descriptor.
 * @param path - file to hash.
 * @param signal - cancellation signal.
 * @returns hex digest and bytes consumed, or the error that stopped it.
 */
export declare function hashFile(path: string, signal: AbortSignal): Promise<{
    ok: true;
    digest: string;
    bytes: number;
} | {
    ok: false;
    error: unknown;
}>;
/**
 * Collect every regular file below a root, read-only.
 * @param root - absolute directory.
 * @param options - budgets and cancellation.
 * @returns candidates, unreadable paths, and coverage notes.
 */
export declare function collectFiles(root: string, options: {
    maxFiles: number;
    maxDepth: number;
    signal: AbortSignal;
    maxErrors: number;
}): Promise<{
    files: CandidateFile[];
    unreadable: UnreadableFile[];
    truncated: boolean;
    notes: string[];
}>;
/**
 * Find byte-identical files below a root.
 *
 * Only files that share a size are hashed, and hashing stops at
 * `maxBytesHashed`. A file that is skipped because of the byte budget is not
 * silently dropped: it is counted in `notes` and reflected in `truncated`, so
 * the caller can tell "no duplicates" from "no duplicates among what I read".
 * @param root - absolute directory.
 * @param options - budgets and cancellation.
 * @returns duplicate groups, reclaimable bytes, and full coverage accounting.
 */
export declare function findDuplicates(root: string, options: DuplicateOptions): Promise<DuplicateReport>;
