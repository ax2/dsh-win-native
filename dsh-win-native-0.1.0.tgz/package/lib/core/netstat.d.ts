/**
 * Interpretation of pasted Windows socket listings.
 *
 * The parser handles the two dialects an agent actually receives: classic
 * `netstat -ano`/`-anob` console output and PowerShell `Get-NetTCPConnection`
 * table output. It deliberately does not invent facts the text cannot carry —
 * there is no way to know from `netstat` text whether a listening PID is still
 * alive, so that question is reported as unanswerable instead of guessed.
 * @module dsh-win-native/core/netstat
 */
/** Which input format was recognized. */
export type NetstatDialect = 'netstat' | 'powershell' | 'unknown';
/** One parsed socket row. */
export interface SocketRow {
    /** `tcp` or `udp`, lower case. */
    protocol: 'tcp' | 'udp';
    /** Address as written, without the port. `*` and `[::]` are kept verbatim. */
    local_address: string;
    /** Local port, or `null` when the text did not carry a numeric port. */
    local_port: number | null;
    /** Remote address, empty for a listening or unconnected socket. */
    remote_address: string;
    /** Remote port, or `null`. */
    remote_port: number | null;
    /** TCP state as written (`LISTENING`, `ESTABLISHED`, ...); empty for UDP. */
    state: string;
    /** Owning process id, or `null` when the row carried none. */
    pid: number | null;
    /** Executable name from `netstat -b`, or `null`. */
    process_name: string | null;
    /** 1-based line number in the input, so a human can find the row. */
    line: number;
    /** Raw row text, trimmed. */
    raw: string;
}
/** One duplicate bind: the same protocol and port claimed more than once. */
export interface DuplicateBind {
    /** `tcp` or `udp`. */
    protocol: 'tcp' | 'udp';
    /** The contested port. */
    port: number;
    /** Every distinct binding of that port. */
    bindings: {
        address: string;
        pid: number | null;
        state: string;
        line: number;
    }[];
    /** Whether one of the bindings is the wildcard address. */
    wildcard_conflict: boolean;
    /** Whether more than one distinct PID claims the port. */
    multi_pid: boolean;
}
/** Established connections rolled up by remote endpoint. */
export interface EndpointGroup {
    /** `host:port` (IPv6 in brackets exactly as written). */
    remote: string;
    /** Number of rows in this group. */
    connections: number;
    /** Distinct owning process ids. */
    pids: number[];
    /** Distinct local endpoints involved. */
    local_endpoints: string[];
    /** Distinct states seen in this group. */
    states: string[];
}
/** Parsed socket listing. */
export interface NetstatReport {
    /** Recognized input dialect. */
    dialect: NetstatDialect;
    /** Rows parsed, in input order. */
    rows: SocketRow[];
    /** Row count per TCP state, upper-cased. */
    state_counts: {
        state: string;
        count: number;
    }[];
    /** Row count per protocol. */
    protocol_counts: {
        protocol: string;
        count: number;
    }[];
    /** Listening TCP endpoints (and UDP binds, which are always "listening"). */
    listening: {
        protocol: 'tcp' | 'udp';
        address: string;
        port: number | null;
        pid: number | null;
        process_name: string | null;
        line: number;
    }[];
    /** Established connections grouped by remote endpoint. */
    established: EndpointGroup[];
    /** Ports bound more than once for the same protocol. */
    duplicate_binds: DuplicateBind[];
    /** Counters that are exact and useful at a glance. */
    summary: {
        tcp_rows: number;
        udp_rows: number;
        listening_tcp: number;
        listening_udp: number;
        established: number;
        distinct_pids: number;
        ports: number;
    };
    /** What the text does not and cannot say. */
    limitations: string[];
    /** Non-fatal parse observations. */
    notes: string[];
}
/**
 * Split a `host:port` token. IPv6 arrives as `[::]:135` or `[fe80::1%12]:445`,
 * so the port is always the text after the last colon that follows a bracket.
 * @param token - address token from a socket row.
 * @returns address, port, and whether the port was numeric.
 */
export declare function splitEndpoint(token: string): {
    address: string;
    port: number | null;
    raw_port: string;
};
/**
 * Detect the dialect of a socket listing.
 * @param text - pasted output.
 */
export declare function detectDialect(text: string): NetstatDialect;
/**
 * Parse a pasted `netstat -ano` / `-anob` or `Get-NetTCPConnection` listing.
 *
 * Rows whose shape is not understood are skipped and counted in `notes`; the
 * parser never throws on malformed text and never fills a field with a guess.
 * @param text - pasted listing.
 * @returns the parsed report.
 */
export declare function parseNetstat(text: string): NetstatReport;
/**
 * Find ports bound more than once for the same protocol.
 *
 * A wildcard bind (`0.0.0.0` or `[::]`) plus a specific-address bind on the same
 * port is the classic Windows "port already in use but something still answers"
 * shape, and it is invisible unless the two rows are compared.
 * @param rows - every parsed row.
 */
export declare function findDuplicateBinds(rows: readonly SocketRow[]): DuplicateBind[];
/** Whether an address is a wildcard bind. */
export declare function isWildcard(address: string): boolean;
