/**
 * Bounded, read-only directory accounting.
 *
 * Two rules shape this module. First, it never writes: no temp files, no
 * indexes, no caches. Second, it never lies about what it skipped — a reparse
 * point that was not followed, a budget that stopped the walk, and a file that
 * could not be stat'ed are all reported as data, because a directory total that
 * silently omits an entire junction target is worse than no total at all.
 * @module dsh-win-native/core/dirwalk
 */
import { type Dirent, type Stats } from 'node:fs';
/** Budgets and safety knobs for one walk. */
export interface WalkOptions {
    /** Maximum files accounted before the walk stops early. */
    maxFiles: number;
    /** Maximum directory depth below the root; the root's own children are depth 1, so `1` accounts only the root's files. */
    maxDepth: number;
    /** Maximum total bytes accounted before the walk stops early. */
    maxBytes: number;
    /** How many of the largest files to return. */
    topN: number;
    /** How many unreadable entries to report. */
    maxErrors: number;
    /** Cancellation signal, checked between entries. */
    signal: AbortSignal;
}
/** One file accounted during a walk. */
export interface WalkFile {
    /** Path as walked. */
    path: string;
    /** Size in bytes. */
    size: number;
    /** Depth below the root, the root's own children being 1. */
    depth: number;
}
/** A path that was deliberately not followed. */
export interface SkippedLink {
    /** Path of the reparse point. */
    path: string;
    /** Depth below the root. */
    depth: number;
    /** Why it was skipped. */
    reason: string;
}
/** An entry that could not be inspected. */
export interface WalkError {
    /** Path that failed. */
    path: string;
    /** Node error code, for example `EACCES` or `ENOENT`. */
    code: string;
    /** Node error message. */
    message: string;
}
/** Result of one bounded walk. */
export interface WalkResult {
    /** Root that was walked. */
    root: string;
    /** Total bytes of the files that were accounted. */
    total_bytes: number;
    /** Files accounted. */
    files: number;
    /** Directories entered. */
    directories: number;
    /** Largest files, descending by size. */
    largest: WalkFile[];
    /** File count and byte total per extension, descending by bytes. */
    extensions: {
        extension: string;
        files: number;
        bytes: number;
    }[];
    /** Reparse points that were not followed. */
    skipped_links: SkippedLink[];
    /** Entries that could not be inspected. */
    unreadable: WalkError[];
    /** Whether a budget stopped the walk before it finished. */
    truncated: boolean;
    /** Budget notes, in the order the budgets were hit. */
    notes: string[];
}
/** Whether a directory entry is a symlink, junction, or other reparse point. */
export declare function isReparsePoint(entry: Dirent | Stats): boolean;
/** Lower-cased extension including the dot, or `(none)`. */
export declare function extensionOf(path: string): string;
/**
 * Walk a directory tree, read-only, within explicit budgets.
 *
 * The loop yields to the event loop every `yieldEvery` entries and checks the
 * abort signal every entry, so a caller can cancel a walk over a large tree
 * instead of waiting for it to finish.
 * @param root - absolute directory to walk.
 * @param options - budgets, top-N size, and cancellation.
 * @returns totals, largest files, extension histogram, and everything skipped.
 */
export declare function walkDirectory(root: string, options: WalkOptions): Promise<WalkResult>;
