/**
 * Pure Windows path legality analysis.
 *
 * This module never touches the filesystem: it answers "what is wrong with this
 * path string on Windows" from the text alone. That is deliberate, because the
 * paths an agent must judge are usually paths it should not open (a user pasted
 * a path that does not exist yet, or a path on a host that is not this one).
 * @module dsh-win-native/core/winpath
 */
/** Stable issue codes reported by {@link inspectPath}. */
export declare const PATH_ISSUE_CODES: readonly ["empty", "not_absolute", "extended_prefix", "unc_path", "drive_relative", "root_relative", "no_root", "invalid_drive_letter", "illegal_char", "control_char", "reserved_name", "trailing_space_or_dot", "segment_trailing_space_or_dot", "segment_too_long", "path_too_long", "above_max_path", "empty_segment", "dot_segment", "not_8_3_safe", "extended_prefix_with_relative"];
/** One issue code. */
export type PathIssueCode = (typeof PATH_ISSUE_CODES)[number];
/** One finding about a path. */
export interface PathIssue {
    /** Stable machine-readable code. */
    code: PathIssueCode;
    /** `error` blocks the path, `warning` means it works but is fragile. */
    severity: 'error' | 'warning';
    /** Human-readable explanation of this specific occurrence. */
    detail: string;
    /** 0-based character offset in the original input, or `null` for whole-path issues. */
    position: number | null;
}
/** Result of analysing one Windows path. */
export interface PathInspection {
    /** The input, echoed unchanged so the caller can correlate. */
    input: string;
    /** Whether the path names an absolute location. */
    absolute: boolean;
    /** Whether the path carries the `\\?\` extended-length prefix. */
    extended: boolean;
    /** `drive` (C:\...), `unc` (\\server\share), `rooted` (\foo) or `none`. */
    kind: 'drive' | 'unc' | 'rooted' | 'none';
    /** Drive letter without the colon, when present. */
    drive: string | null;
    /** Normalized `\\?\`-style extended form. */
    canonical: string;
    /** Character length of the original path, as Windows counts it. */
    length: number;
    /** Length of the normalized form. */
    canonical_length: number;
    /** Effective MAX_PATH ceiling for this path kind. */
    max_path_limit: number;
    /** Whether the path is usable without long-path support. */
    safe_for_max_path: boolean;
    /** Whether long-path (`\\?\` or the LongPathsEnabled policy) is required. */
    requires_extended_prefix: boolean;
    /** Per-segment 8.3 compatibility. */
    segments: PathSegment[];
    /** All findings, in path order. */
    issues: PathIssue[];
}
/** One path segment. */
export interface PathSegment {
    /** Segment text as written. */
    value: string;
    /** Index of the segment, the drive/UNC root counting as 0. */
    index: number;
    /** Whether the segment is a legal 8.3 short name. */
    safe_8_3: boolean;
    /** Length in characters. */
    length: number;
}
/** Characters Windows forbids in a file or directory name. */
export declare const ILLEGAL_CHARACTERS: readonly ["<", ">", ":", "\"", "|", "?", "*"];
/** Reserved DOS device names, matched case-insensitively with or without an extension. */
export declare const RESERVED_NAMES: readonly ["CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"];
/** The classic MAX_PATH ceiling, which counts the terminating NUL. */
export declare const MAX_PATH = 260;
/** Longest path Windows accepts through the extended-length prefix (32,767 including the NUL). */
export declare const EXTENDED_MAX_PATH = 32767;
/** Longest single segment (255 characters), the per-component NTFS limit. */
export declare const MAX_SEGMENT = 255;
/**
 * Split a Windows path into its segments, ignoring repeated separators.
 * @param path - path text.
 * @returns non-empty segments.
 */
export declare function splitSegments(path: string): string[];
/**
 * Whether a name matches a reserved DOS device name, with or without extension.
 * `CON.txt`, `nul.log` and `COM1` are all reserved; `CONSOLE.txt` is not.
 * @param name - one path segment.
 */
export declare function isReservedName(name: string): boolean;
/**
 * Whether one segment is a legal 8.3 short name. Long names are not "wrong" on
 * modern Windows, but they break on FAT-formatted removable media and on tools
 * that still generate short names, so this is reported as a warning.
 * @param name - one path segment.
 */
export declare function isShortNameSafe(name: string): boolean;
/**
 * Build the canonical `\\?\`-prefixed form of an absolute path.
 *
 * The prefix is what actually lifts the 260-character limit; normalizing here
 * means a caller can take the result straight to `fs` or to a child process and
 * get the same file, instead of silently hitting MAX_PATH on a deep tree.
 * @param path - an absolute path, possibly already prefixed.
 * @returns the normalized form, or the input when it is not absolute.
 */
export declare function toExtendedPath(path: string): string;
/**
 * Remove `.` and `..` segments from a path **textually**.
 *
 * This is deliberately not `path.resolve`: resolving against the process working
 * directory would make the answer depend on how the host was started, which is
 * exactly the class of bug this plugin exists to remove. `..` is folded only when
 * the preceding segment is a plain name, so `C:\..\x` and `..\x` keep their
 * meaning instead of being silently reinterpreted.
 * @param path - path text.
 * @returns folded path, plus whether any unprefixed `..` segment survived.
 */
export declare function foldRelative(path: string): {
    path: string;
    unresolved: boolean;
};
/**
 * Inspect a Windows path string for every legality rule an agent trips over.
 *
 * The checks, in the order a Windows API applies them: absolute vs relative,
 * extended-length prefix, UNC vs drive vs root-relative, drive-relative `C:foo`,
 * per-segment illegality (reserved names, illegal characters, control
 * characters, trailing space or dot, 255-character length), and finally the
 * whole-path length against both MAX_PATH and the extended limit.
 * @param input - candidate path, as the user wrote it.
 * @returns findings, canonical form, and length verdicts.
 */
export declare function inspectPath(input: string): PathInspection;
