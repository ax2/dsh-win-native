/** Token-neutral accounting attached to every successful result. */
export interface ToolMeta {
    /** UTF-8 bytes read from the primary input field. */
    bytesIn: number;
    /** UTF-8 bytes of the canonical result payload. */
    bytesOut: number;
    /** Whether a budget clipped the input or the result. */
    truncated: boolean;
    /** Ordered, human-readable notes: budgets, fallbacks, skipped entries. */
    notes: string[];
}
/** Canonical value returned by every tool in this package. */
export interface Envelope<T> {
    /** The tool-specific payload. */
    result: T;
    /** Byte accounting and notes for this call. */
    meta: ToolMeta;
}
/** Model-facing text block (structurally identical to `@deepseek-ai/dsh-llm` ContentBlock). */
export interface TextBlock {
    readonly type: 'text';
    readonly text: string;
}
/**
 * Build the meta block for one call.
 * @param bytesIn - measured input bytes.
 * @param result - canonical payload used to measure the output.
 * @param notes - accumulated notes.
 * @param truncated - whether a budget clipped anything.
 */
export declare function metaOf(bytesIn: number, result: unknown, notes?: readonly string[], truncated?: boolean): ToolMeta;
/** Wrap a payload with its accounting. */
export declare function envelope<T>(result: T, bytesIn: number, notes?: readonly string[], truncated?: boolean): Envelope<T>;
/**
 * Render an envelope for the model: the payload itself, plus a footer only when
 * something needs saying. A clean call costs no extra tokens.
 * @param value - canonical envelope.
 * @returns model-facing content blocks.
 */
export declare function renderEnvelope(value: Envelope<unknown>): TextBlock[];
