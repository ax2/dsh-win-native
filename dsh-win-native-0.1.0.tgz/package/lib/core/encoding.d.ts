/** Every encoding this plugin can decode from or encode to. */
export declare const SOURCE_ENCODINGS: readonly ["auto", "utf-8", "utf-16le", "utf-16be", "gbk", "gb18030", "big5", "shift_jis", "latin1", "ascii"];
/** Every encoding accepted as a conversion target (`auto` is meaningless there). */
export declare const TARGET_ENCODINGS: readonly ["utf-8", "utf-16le", "utf-16be", "gbk", "gb18030", "big5", "shift_jis", "latin1", "ascii"];
/** BOM handling policy for the converted output. */
export declare const BOM_POLICIES: readonly ["keep", "add", "strip"];
/** One encoding name accepted by this module. */
export type SourceEncoding = (typeof SOURCE_ENCODINGS)[number];
/** One conversion target name. */
export type TargetEncoding = (typeof TARGET_ENCODINGS)[number];
/** One BOM policy name. */
export type BomPolicy = (typeof BOM_POLICIES)[number];
/** Confidence that the reported encoding is the right one. */
export type Confidence = 'high' | 'medium' | 'low';
/** Byte-order marks, longest first so UTF-32 is not mistaken for UTF-16. */
export declare const BOMS: readonly {
    encoding: string;
    bytes: readonly number[];
}[];
/** One candidate decoding of a payload. */
export interface EncodingCandidate {
    /** Canonical encoding name. */
    encoding: string;
    /** 0 (implausible) to 1 (clean), derived from the signals listed below. */
    score: number;
    /**
     * Internal ordering key: `score` plus the documented code-page prior. Two
     * candidates can share the same `score` and still be ordered by `ranked`.
     */
    ranked: number;
    /** Characters the decoder could not map, i.e. U+FFFD. */
    replacements: number;
    /** Characters that are structurally decodable but implausible in real text. */
    suspicious: number;
    /** Characters in ranges that this code page only reaches with unusual byte pairs. */
    implausible_scripts: number;
    /** Whether re-encoding the decoded text reproduces the original bytes exactly. */
    round_trip: boolean;
    /** Short decoded sample, so a human can judge the guess. */
    sample: string;
}
/** Detection result for one payload. */
export interface EncodingDetection {
    /** Best candidate encoding name. */
    encoding: string;
    /** Confidence in `encoding`; `low` means "report the alternatives, do not act on this". */
    confidence: Confidence;
    /** Detected byte-order mark, or `none`. */
    bom: string;
    /** Payload length in bytes. */
    byte_length: number;
    /** Ordered candidates, best first, including the winner. */
    alternatives: EncodingCandidate[];
    /** Machine-readable signal codes explaining the decision. */
    signals: string[];
}
/**
 * Decode bytes with a canonical encoding name, including the UTF-16 variants
 * that `iconv-lite` does not expose directly.
 * @param bytes - raw bytes, without any BOM.
 * @param encoding - canonical encoding name.
 * @returns decoded text.
 */
export declare function decodeBytes(bytes: Buffer, encoding: string): string;
/**
 * Encode text with a canonical encoding name, including the UTF-16 variants.
 * @param text - text to encode.
 * @param encoding - canonical encoding name from {@link TARGET_ENCODINGS}.
 * @returns encoded bytes without a BOM.
 */
export declare function encodeText(text: string, encoding: string): Buffer;
/** Detect the BOM at the start of a payload. */
export declare function detectBom(bytes: Buffer): {
    encoding: string;
    length: number;
};
/** Return the BOM bytes for an encoding, or an empty buffer when it has none. */
export declare function bomFor(encoding: string): Buffer;
/**
 * Whether the payload is valid strict UTF-8. Uses the platform decoder with
 * `fatal`, which is a real validator rather than a permissive re-decode.
 * @param bytes - raw bytes.
 */
export declare function isStrictUtf8(bytes: Buffer): boolean;
/**
 * Share of lead bytes that only Shift-JIS uses in practice.
 *
 * GB18030's coverage of the 0x81-0x9F lead range is real but narrow (it reaches
 * Greek, Cyrillic and a few hundred rare CJK characters there), while Shift-JIS
 * puts its entire Hiragana block and much of its Kanji block there. A payload
 * whose multi-byte characters overwhelmingly live in that range is therefore
 * weak evidence for Shift-JIS, used only to avoid reporting a Japanese text file
 * as GB18030 with a straight face.
 * @param bytes - the payload.
 * @returns fraction in `[0, 1]`.
 */
export declare function lowLeadShare(bytes: Buffer): number;
/**
 * Detect the encoding of a payload.
 *
 * Order of evidence: BOM, then strict UTF-8 validation, then a scored decode of
 * each candidate code page. This mirrors how the failure actually happens on
 * Windows: a BOM is authoritative, a strict-UTF-8 payload is almost always
 * UTF-8, and everything else is a probabilistic call that must be reported as
 * such.
 * @param bytes - raw payload bytes.
 * @param options - `sampleChars` bounds the decoded sample per candidate.
 * @returns detection result with ordered alternatives and signal codes.
 */
export declare function detectEncoding(bytes: Buffer, options?: {
    sampleChars?: number;
}): EncodingDetection;
/** One character that a conversion could not represent. */
export interface LossyCharacter {
    /** The code point that had no target representation. */
    code_point: string;
    /** `U+xxxx` spelling, for a human reader. */
    char: string;
    /** How many times it occurred. */
    count: number;
}
/** Result of converting one payload between encodings. */
export interface ConversionResult {
    /** Encoding actually used for the source. */
    source_encoding: string;
    /** Encoding used for the output. */
    target_encoding: string;
    /** Detected source BOM name, or `none`. */
    source_bom: string;
    /** BOM name written to the output, or `none`. */
    output_bom: string;
    /** Number of characters that could not be represented in the target. */
    lossy_characters: number;
    /** The distinct characters responsible, bounded by the caller. */
    lossy_list: LossyCharacter[];
    /** Decoded source text (bounded by the caller). */
    text: string;
    /** Length of the decoded source text before any caller bound was applied. */
    fullTextLength: number;
    /** Whether the payload changed at all. */
    changed: boolean;
    /** Machine-readable signal codes. */
    signals: string[];
}
/**
 * Convert bytes from one encoding to another, reporting every character the
 * target could not represent.
 *
 * Lossiness is measured by decoding the result back and comparing, not by
 * trusting the encoder: `iconv-lite` substitutes `?` without an error, so the
 * only reliable check is a round trip over the produced bytes.
 * @param bytes - source bytes, BOM included.
 * @param from - source encoding, or `auto` to detect.
 * @param to - target encoding.
 * @param bomPolicy - what to do with the byte-order mark.
 * @param options - `textChars` bounds the returned decoded text, `lossyListMax` the loss list.
 */
export declare function convertEncoding(bytes: Buffer, from: SourceEncoding, to: TargetEncoding, bomPolicy: BomPolicy, options?: {
    textChars?: number;
    lossyListMax?: number;
}): {
    result: ConversionResult;
    output: Buffer;
    detection?: EncodingDetection;
};
/**
 * Compare the original text with the text recovered from the encoded bytes and
 * list the characters that did not survive.
 * @param original - decoded source text.
 * @param recovered - text decoded back from the encoded bytes.
 */
export declare function collectLossy(original: string, recovered: string): {
    total: number;
    list: LossyCharacter[];
};
/** Whether an encoding name is a supported conversion source. */
export declare function isSourceEncoding(value: string): value is SourceEncoding;
/** Whether an encoding name is a supported conversion target. */
export declare function isTargetEncoding(value: string): value is TargetEncoding;
/** Whether a BOM policy name is supported. */
export declare function isBomPolicy(value: string): value is BomPolicy;
